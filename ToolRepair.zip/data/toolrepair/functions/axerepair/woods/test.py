import shutil
import os
import glob

tooltypes = ['axe', 'pickaxe']

for file in glob.glob(f'./**/*.mcfunction', recursive=True):
    with open(file, 'r') as txtfile:
        data = txtfile.read()

        data.replace('sword', 'pickaxe')
    
    with open(file, 'w') as txtfile:
        txtfile.write(data)